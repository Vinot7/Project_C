#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
typedef struct Date {
	int jour;
	int mois;
	int annee;
}date;
typedef struct 	Voiture{
	int idVoiture;
	char marque[15];
	char nomVoiture[15];
	char couleur[7];
	int nbplaces;
	int prixJour;
	char EnLocation[4];
}voiture;
typedef struct contratLocation{
	float numContrat;
	int idVoiture;
	int idClient;
	date debut;
	date fin;
	int cout;
}contrat;
typedef struct Client{
	int idClient;
	char nom[15];
	char prenom[15];
	int cin;
	char adresse[15];
	int telephone;
}client;
typedef struct listevoiture{
	voiture valeur;
	struct listevoiture *suivant;
}listeVoiture;
typedef struct listeclient{
	client valeur;
	struct listeclient *suivant;
}listeClient;
typedef struct listecontrat{
	contrat valeur;
	struct listecontrat *suivant;
}listeContrat;
listeVoiture **L;
listeClient **L1;
listeContrat **L2;
void Location(){
	int choix;
	do{
	printf("\n                               \xda\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xbf");
	printf("\n                               \xb3 Location d'une voiture \xb3");
	printf("\n                               \xc0\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xd9");

	printf("\n\n");

	printf("\n               \xc9\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbb");
	printf("\n               \xba                                              \xba");
	printf("\n               \xba    Visualiser contrat....................1   \xba");
	printf("\n               \xba    Louer voiture.........................2   \xba");
	printf("\n               \xba    Retourner voiture.....................3   \xba");
	printf("\n               \xba    Modifier contrat......................4   \xba");
	printf("\n               \xba    Supprimer contrat.....................5   \xba");
	printf("\n               \xba    Retour................................6   \xba");
	printf("\n               \xba                                              \xba");
	printf("\n               \xc8\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbc");
	printf("\n\n                                Votre choix  :  ");
    scanf("%d",&choix);
 }while(choix<1 || choix>6);
 switch(choix){
 	case 1: ajouterContrat(L2);
 	        break;
 	case 2: louerVoiture();
 		    break;
 	case 3: retournerVoiture();
	        break;
 	case 4: MOdifierContrat(&L2);
 	        break;
 	case 5: suppressionContrat(&L2);
 	        break;
 	default:menuprincipal();
 	         break;
    }
}
void gestionVoitures(){
	int choix;
	do{
	printf("\n                               \xda\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xbf");
	printf("\n                               \xb3 Gestion des Voitures \xb3");
	printf("\n                               \xc0\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xd9");

	printf("\n\n");

	printf("\n               \xc9\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbb");
	printf("\n               \xba                                              \xba");
	printf("\n               \xba    Liste des voitures....................1   \xba");
	printf("\n               \xba    Ajouter voiture.......................2   \xba");
	printf("\n               \xba    Modifier voiture......................3   \xba");
	printf("\n               \xba    Supprimer voiture.....................4   \xba");
	printf("\n               \xba    Retour................................5   \xba");
	printf("\n               \xba                                              \xba");
	printf("\n               \xc8\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbc");
	printf("\n\n                                Votre choix  :  ");
    scanf("%d",&choix);
 }while(choix<1 || choix>5);
 switch(choix){
 	case 1: listevoiture();
 	        break;
 	case 2: ajouterVoiture(&L);
 	        break;
 	case 3: ModifierVoiture(&L);
 	        break;
 	case 4: supprimerVoiture(&L);
 	        break;
 	default:menuprincipal();
 	         break;
    }
}
void gestionClient(){
	int choix;
	do{
	printf("\n                               \xda\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xbf");
	printf("\n                               \xb3 Gestion des clients  \xb3");
	printf("\n                               \xc0\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xd9");

	printf("\n\n");

	printf("\n               \xc9\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbb");
	printf("\n               \xba                                              \xba");
	printf("\n               \xba    Liste des Clients.....................1   \xba");
	printf("\n               \xba    Ajouter Client........................2   \xba");
	printf("\n               \xba    Modifier Client.......................3   \xba");
	printf("\n               \xba    Supprimer Client......................4   \xba");
	printf("\n               \xba    Retour................................5   \xba");
	printf("\n               \xba                                              \xba");
	printf("\n               \xc8\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbc");
	printf("\n\n                                Votre choix  :  ");
    scanf("%d",&choix);
 }while(choix<1 || choix>5);
 switch(choix){
 	case 1: listeclient();
 	        break;
 	case 2: AjouterClient(L1);
 	        break;
 	case 3: MOdifierClient(&L1);
 	        break;
 	case 4: suppressionClient(&L1);
 	        break;
 	default: menuprincipal();
 	        break;
    }
}
void menuprincipal(){
	int choix;
do{
	printf("\n                               \xda\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xbf");
	printf("\n                               \xb3 Menu Principale \xb3");
	printf("\n                               \xc0\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xd9");

	printf("\n\n");

	printf("\n               \xc9\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbb");
	printf("\n               \xba                                              \xba");
	printf("\n               \xba    Location..............................1   \xba");
	printf("\n               \xba    Gestion Voiture.......................2   \xba");
	printf("\n               \xba    Gestion Clients.......................3   \xba");
	printf("\n               \xba    Quitter...............................4   \xba");
	printf("\n               \xba                                              \xba");
	printf("\n               \xc8\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbc");
	printf("\n\n                                Votre choix  :  ");
    scanf("%d",&choix);
 }while(choix<1 || choix>5);
 switch(choix){
 	case 1: Location();
 	        break;
 	case 2: gestionVoitures();
 	        break;
 	case 3: gestionClient();
 	        break;
 	default: exit(0);
 	         break;
}
}
void InitialisationContrat(listeContrat **L2){ /*initiates the contract file*/
	 listeContrat*E=NULL;
	E=(listeContrat*)malloc(sizeof(listeContrat));
	if(E==NULL){
		printf("Pas d'espace memoire !");
		exit(1);
	}
	E->valeur.numContrat=1;
	E->valeur.idVoiture=1;
	E->valeur.idClient=1;
	E->valeur.debut.jour=8;
	E->valeur.debut.mois=7;
	E->valeur.debut.annee=2021;
	E->valeur.fin.jour=17;
	E->valeur.fin.mois=7;
	E->valeur.fin.annee=2021;
    E->valeur.cout=3000;
    E->suivant=*L2;
	*L2=E;
	listeContrat *Z;
	Z=*L2;
	FILE *fichier=NULL; /*adds the modified data to the contract file*/
	fichier=fopen("contrat.txt","w");
	if(fichier==NULL){
	 printf("Le fichier n'existe pas!");
	}
	else{
    while(Z){
		fprintf(fichier,"%.2f %d %d   %d %d %d    %d %d %d   %d \n",Z->valeur.numContrat,Z->valeur.idVoiture,Z->valeur.idClient,Z->valeur.debut.jour,Z->valeur.debut.mois,Z->valeur.debut.annee,Z->valeur.fin.jour,Z->valeur.fin.mois,Z->valeur.fin.annee,Z->valeur.cout);
		Z=Z->suivant;
	}
	fclose(fichier);
	}
}
void listecontrat(listeContrat *L2){ /*shows the contract with the entered number*/
	listeContrat *E=L2;
	float numcont;
	printf("Entrez le numero de contrat:");
	scanf("%f",&numcont);
	while(E){
		if((E->valeur.numContrat-numcont)==0){
		 printf("%.2f %d %d   %d %d %d    %d %d %d   %d\n",E->valeur.numContrat,E->valeur.idVoiture,E->valeur.idClient,E->valeur.debut.jour,E->valeur.debut.mois,E->valeur.debut.annee,E->valeur.fin.jour,E->valeur.fin.mois,E->valeur.fin.annee,E->valeur.cout);
	    }
		E=E->suivant;
	}
}
void ajouterContrat(listeContrat **L2){
	listeContrat*E=NULL;
	E=(listeContrat*)malloc(sizeof(listeContrat));
	if(E==NULL){
		printf("Pas d'espace memoire !");
		exit(1);
	}
	else{
		printf("Entrer le numero de contrat:");
		scanf("%f",&E->valeur.numContrat);
		printf("Entrer l'id de Voiture :");
		scanf("%d",&E->valeur.idVoiture);
		printf("Entrer l'id du client:");
		scanf("%d",&E->valeur.idClient);
		printf("Entrer le jours de debut de Location:");
		scanf("%d",&E->valeur.debut.jour);
		printf("Entrer le mois de debut de Location :");
		scanf("%d",&E->valeur.debut.mois);
		printf("Entrer l'annee de debut de Location :");
		scanf("%d",&E->valeur.debut.annee);
		printf("Entrer le jour de fin de Location :");
		scanf("%d",&E->valeur.fin.jour);
		printf("Entrer le mois de fin de Location :");
		scanf("%d",&E->valeur.fin.mois);
		printf("Entrer l'annee de fin de Location :");
		scanf("%d",&E->valeur.fin.annee);
		printf("Entre le cout:");
		scanf("%d",&E->valeur.cout);
        E->suivant=*L2;
	    *L2=E;
	    listeContrat *Z;
	    Z=*L2;
	    FILE *fichier=NULL; /*adds the modified data to the contract file*/
	    fichier=fopen("contrat.txt","w");
	    if(fichier==NULL){
		 printf("Le fichier n'existe pas!");
	    }
	    else{
		 while(Z){
			fprintf(fichier,"%.2f %d %d   %d %d %d    %d %d %d   %d \n",Z->valeur.numContrat,Z->valeur.idVoiture,Z->valeur.idClient,Z->valeur.debut.jour,Z->valeur.debut.mois,Z->valeur.debut.annee,Z->valeur.fin.jour,Z->valeur.fin.mois,Z->valeur.fin.annee,Z->valeur.cout);
			Z=Z->suivant;
		 }
		 fclose(fichier);
	    }
    }
}

void retournerVoiture(){
	int ID,i=0;
	printf("Entrer l'ID de voiture:");
	scanf("%s",&ID);
	listeVoiture *tmp=L;
	while(tmp){ /*verifies if the car with the entered ID exists in the cars file*/
		if(tmp->valeur.idVoiture==ID)
		 i++;
		tmp=tmp->suivant;
	}
	if(i==0)
	 printf("Voiture n'existe pas! \n");
	if(i!=0){
	while(tmp){ /*finds the car with the entered ID and deletes its contract*/
		if(tmp->valeur.idVoiture==ID){
			 	strncpy (tmp->valeur.EnLocation,"Non", 4);
                suppressionContrat(&L2);
		}
	 tmp=tmp->suivant;
	}
	}
}
void louerVoiture(){
	char NOM[15],PRENOM[15];
	int ID,i=0,j=0;
	printf("Entrer votre nom:");
	scanf("%s",NOM);
	printf("Entrer votre prenom:");
	scanf("%s",&PRENOM);
	printf("Entrer l'ID de voiture:");
	scanf("%s",&ID);
	listeVoiture *tmp=L;
	listeClient *ptr=L1;
	while(tmp){ /*verifies if the car with the entered ID exists in the cars file*/
		if(tmp->valeur.idVoiture==ID)
		 i++;
		tmp=tmp->suivant;
	}
	while(ptr){/*verifies if the client exists in the clients file*/
		if(strcmp(ptr->valeur.nom,NOM)==0 && strcmp(ptr->valeur.prenom,PRENOM)==0)
		 j++;
		ptr=ptr->suivant;
	}
	if(j==0)
	 printf("Client introuvable ! Veuillez entrer vos propres informations a travers Gestion clients. \n");
	if(i==0)
	 printf("Voiture n'existe pas! \n");
	if(i!=0 && j!=0){
	while(tmp){ /*verifies if the car with the entered ID is available for rent. if it is, lets the client fill up a new contract*/
		if(tmp->valeur.idVoiture==ID){
			if(strcmp(tmp->valeur.EnLocation,"Non")==0){
			 	strncpy (tmp->valeur.EnLocation,"Oui", 4);
			 	ajouterContrat(&L2);
		    }
			else
			printf("Voiture n'est pas disponible!");
		}

	 tmp=tmp->suivant;
	}
	}
}
void suppressionContrat(listeContrat **L2){
	listeContrat *prec;
	listeContrat *ptr=*L2;
	prec=NULL;
	int i=0;
	float  num;
	printf("Entrer le numero de contrat:");
	scanf("%f",&num);
	if(!ptr->suivant && num==ptr->valeur.numContrat){ /*if there's only on element in the list, checks if it is the contract with the entered number and deletes it*/
		*L2=NULL;
		free(ptr);
	}
	else{
	while(ptr->suivant){ /*finds the contract with entered number and stops at the element preceding it*/
		if(num==ptr->suivant->valeur.numContrat){
		 prec=ptr;
		 i++;
	    }
		ptr=ptr->suivant;
	}
	if(i==0)
	 printf("Contrat inconnue! \n");
	else{ /*deletes the contract with entered number*/
		ptr=prec->suivant;
		prec->suivant=prec->suivant->suivant;
		free(ptr);
    }
    }
    listeContrat *Z;
	    Z=*L2;
	    FILE *fichier=NULL; /*adds the modified data to the contract file*/
	    fichier=fopen("contrat.txt","w");
	    if(fichier==NULL){
		 printf("le fichier n'existe pas!");
	    }
	    else{
		 while(Z){
			fprintf(fichier,"%.2f %d %d   %d %d %d    %d %d %d   %d \n",Z->valeur.numContrat,Z->valeur.idVoiture,Z->valeur.idClient,Z->valeur.debut.jour,Z->valeur.debut.mois,Z->valeur.debut.annee,Z->valeur.fin.jour,Z->valeur.fin.mois,Z->valeur.fin.annee,Z->valeur.cout);
			Z=Z->suivant;
		 }
		 fclose(fichier);
	    }
    }
void MOdifierContrat(listeContrat **L2){
	listeContrat *ptr=*L2;
	int num,i=0;
	printf("Entrer le numero de contrat :");
	scanf("%d",&num);
	if(ptr->valeur.numContrat==num){ /*if the contract with the entered number is the first element on the list*/
		printf("Entrer le nouveau numero de contrat");
		scanf("%f",&ptr->valeur.numContrat);
		printf("Entrer la nouvelle id de voiture :");
		scanf("%d",&ptr->valeur.idVoiture);
		printf("Entrer la nouvelle id de client:");
		scanf("%d",&ptr->valeur.idClient);
		printf("Entrer le nouveau jour de debut de Location:");
		scanf("%d",&ptr->valeur.debut.jour);
		printf("Entrer le nouveau mois de debut de Location :");
		scanf("%d",&ptr->valeur.debut.mois);
		printf("Entrer la nouvelle annee de debut de Location :");
		scanf("%d",&ptr->valeur.debut.annee);
		printf("Entrer le nouveau jour de fin de Location :");
		scanf("%d",&ptr->valeur.fin.jour);
		printf("Entrer le nouveau mois de fin de Location :");
		scanf("%d",&ptr->valeur.fin.mois);
		printf("Entrer la nouvelle annee de fin de Location :");
		scanf("%d",&ptr->valeur.fin.annee);
		printf("Entre le nouveau cout:");
		scanf("%d",&ptr->valeur.cout);
	}
	else{
	while(ptr->suivant!=NULL){
		if(ptr->suivant->valeur.numContrat==num){
		printf("Entrer le nouveau num de contrat");
		scanf("%f",&ptr->suivant->valeur.numContrat);
		printf("Entrer la nouvelle id de Voiture :");
		scanf("%d",&ptr->suivant->valeur.idVoiture);
		printf("Entrer la nouvelle id de client:");
		scanf("%d",&ptr->suivant->valeur.idClient);
		printf("Entrer le nouveau jour de debut de Location:");
		scanf("%d",&ptr->suivant->valeur.debut.jour);
		printf("Entrer le nouveau mois de debut de Location :");
		scanf("%d",&ptr->suivant->valeur.debut.mois);
		printf("Entrer la nouvelle annee de debut de Location :");
		scanf("%d",&ptr->suivant->valeur.debut.annee);
		printf("Entrer le nouveau jour de fin de Location :");
		scanf("%d",&ptr->suivant->valeur.fin.jour);
		printf("Entrer le nouveau mois de fin de Location :");
		scanf("%d",&ptr->suivant->valeur.fin.mois);
		printf("Entrer la nouvelle annee de fin de Location :");
		scanf("%d",&ptr->suivant->valeur.fin.annee);
		printf("Entre le nouveau cout:");
		scanf("%d",&ptr->suivant->valeur.cout);
		}
		ptr=ptr->suivant;
	}
    }
}
void InitialisationVoiture(listeVoiture **L){ /*initiates the car file*/
	listeVoiture *E=NULL;
	E=(listeVoiture*)malloc(sizeof(listeVoiture));
	if(E==NULL){
		printf("Pas d'espace memoire !");
		exit(1);
	}
	E->valeur.idVoiture=1;
	strncpy (E->valeur.marque,"FORD", 5);
	strncpy (E->valeur.nomVoiture, "FOCUS", 6);
	strncpy (E->valeur.couleur, "BLACK", 6);
	E->valeur.nbplaces=5;
	E->valeur.prixJour=300;
	strncpy (E->valeur.EnLocation, "Oui", 4);
	E->suivant=*L;
	*L=E;
	listeVoiture *A=NULL;
	A=(listeVoiture*)malloc(sizeof(listeVoiture));
	if(A==NULL){
		printf("Pas d'espace memoire !");
		exit(1);
	}
	A->valeur.idVoiture=2;
	strncpy (A->valeur.marque, "RENAULT", 8);
	strncpy (A->valeur.nomVoiture, "CLIO",5);
	strncpy (A->valeur.couleur, "WHITE", 6);
	A->valeur.nbplaces=4;
	A->valeur.prixJour=400;
    strncpy (A->valeur.EnLocation, "Non", 4);
	A->suivant=*L;
	*L=A;
	listeVoiture *Z=*L;
	FILE *fichier=NULL; /*adds the modified data to the car file*/
	fichier=fopen("voiture.txt","w");
    if(fichier==NULL){
		printf("Le fichier n'existe pas!");
    }
    else{
	 while(Z){
			fprintf(fichier,"%d %s %s %s %d %d %s \n",Z->valeur.idVoiture,Z->valeur.marque,Z->valeur.nomVoiture,Z->valeur.couleur,Z->valeur.nbplaces,Z->valeur.prixJour,Z->valeur.EnLocation);
			Z=Z->suivant;
	 }
	fclose(fichier);
	}
}

void ajouterVoiture(listeVoiture **L){
	listeVoiture *E=NULL;
	E=(listeVoiture*)malloc(sizeof(listeVoiture));
	if(E==NULL){
		printf("Pas d'espace memoire !");
		exit(1);
	}
	else{
		printf("Entrer l'id de voiture :");
		scanf("%d",&E->valeur.idVoiture);
		printf("Entrer la marque:");
		scanf("%s",&E->valeur.marque);
		printf("Entrer le nom de voiture:");
		scanf("%s",&E->valeur.nomVoiture);
		printf("Entrer la couleur:");
		scanf("%s",&E->valeur.couleur);
		printf("Entrer le nombre de places :");
		scanf("%d",&E->valeur.nbplaces);
		printf("Entrer le prix par jour:");
		scanf("%d",&E->valeur.prixJour);
		printf("Entrer enlocation:");
		scanf("%s",&E->valeur.EnLocation);
		E->suivant=*L;
		*L=E;
		FILE *fichier=NULL; /*adds the modified data to the car file*/
	    fichier=fopen("voiture.txt","w");
     	if(fichier==NULL){
		printf("Le fichier n'existe pas!");
     	}
    	else{
		 while(E){
			fprintf(fichier,"%d %s %s %s %d %d %s \n",E->valeur.idVoiture,E->valeur.marque,E->valeur.nomVoiture,E->valeur.couleur,E->valeur.nbplaces,E->valeur.prixJour,E->valeur.EnLocation);
			E=E->suivant;
		 }
		 fclose(fichier);
	     }
    }
}

void listevoiture(){  /*shows the car file data*/
	FILE *fichier=fopen("voiture.txt","r");
	if(fichier==NULL)
	 printf("Erreur!");
	else{
	 char c;
	 do{
	 	c=fgetc(fichier);
	 	printf("%c",c);
	 }while(c!=EOF);
	}
}

void ModifierVoiture(listeVoiture **L){
	listeVoiture *ptr=*L;
	int ID,i=0;
	printf("Entrer l'id de voiture :");
	scanf("%d",&ID);
	if(ptr->valeur.idVoiture==ID){ /*if the car with the entered ID is the first element on the list*/
		printf("Entrer la nouvelle id de voiture :");
		scanf("%d",&ptr->valeur.idVoiture);
		printf("Entrer la nouvelle marque:");
		scanf("%s",&ptr->valeur.marque);
		printf("Entrer le nouveau nom du voiture:");
		scanf("%s",&ptr->valeur.nomVoiture);
		printf("Entrer la nouvelle couleur:");
		scanf("%s",&ptr->valeur.couleur);
		printf("Entrer le nouveau nombre de places :");
		scanf("%d",&ptr->valeur.nbplaces);
		printf("Entrer le nouveau prix par jour:");
		scanf("%d",&ptr->valeur.prixJour);
		printf("Entrer nouveau enlocation:");
		scanf("%s",&ptr->valeur.EnLocation);
	}
	else{
	while(ptr->suivant!=NULL){
		if(ptr->suivant->valeur.idVoiture==ID){
		printf("Entrer la nouvelle id de voiture :");
		scanf("%d",&ptr->suivant->valeur.idVoiture);
		printf("Entrer la nouvelle marque:");
		scanf("%s",&ptr->suivant->valeur.marque);
		printf("Entrer le nouveau nom du voiture:");
		scanf("%s",&ptr->suivant->valeur.nomVoiture);
		printf("Entrer la nouvelle couleur:");
		scanf("%s",&ptr->suivant->valeur.couleur);
		printf("Entrer le nouveau nombre de places :");
		scanf("%d",&ptr->suivant->valeur.nbplaces);
		printf("Entrer le nouveau prix par jour:");
		scanf("%d",&ptr->suivant->valeur.prixJour);
		printf("Entrer nouveau enlocation:");
		scanf("%s",&ptr->suivant->valeur.EnLocation);
		}
		ptr=ptr->suivant;
	}
    }
    listeVoiture *Z=*L;
	FILE *fichier=NULL; /*adds the modified data to the car file*/
	fichier=fopen("voiture.txt","w");
	if(fichier==NULL){
	printf("Le fichier n'existe pas!");
	}
	else{
		while(Z){
			fprintf(fichier,"%d %s %s %s %d %d %s \n",Z->valeur.idVoiture,Z->valeur.marque,Z->valeur.nomVoiture,Z->valeur.couleur,Z->valeur.nbplaces,Z->valeur.prixJour,Z->valeur.EnLocation);
			Z=Z->suivant;
		}
		fclose(fichier);
	}
}

void supprimerVoiture(listeVoiture **L){
	listeVoiture *prec;
	listeVoiture *ptr=*L;
	prec=NULL;
	int Id,i=0;
	printf("Entrer ID:");
	scanf("%d",&Id);
	if(ptr->valeur.idVoiture==Id){
		ptr=ptr->suivant;
	}
	while(ptr->suivant!=NULL){ /*finds the car with entered ID and stops at the element preceding it*/
		if(Id==ptr->suivant->valeur.idVoiture){
		 prec=ptr;
		 i++;
	    }
		ptr=ptr->suivant;
	}
	if(i==0)
	 printf("ID inconnue! \n");
	else{
		ptr=prec->suivant;
		prec->suivant=prec->suivant->suivant;
    }
    listeVoiture *Z=*L;
	FILE *fichier=NULL; /*adds the modified data to the car file*/
	fichier=fopen("voiture.txt","w");
	if(fichier==NULL){
	printf("Le fichier n'existe pas!");
	}
	else{
		while(Z){
			fprintf(fichier,"%d %s %s %s %d %d %s \n",Z->valeur.idVoiture,Z->valeur.marque,Z->valeur.nomVoiture,Z->valeur.couleur,Z->valeur.nbplaces,Z->valeur.prixJour,Z->valeur.EnLocation);
			Z=Z->suivant;
		}
		fclose(fichier);
	}

}
void InitialisationClient(listeClient **L1){
	listeClient *E=NULL;
	E=(listeClient*)malloc(sizeof(listeClient));
	if(E==NULL){
		printf("Pas d'espace memoire !");
		exit(1);
	}
	E->valeur.idClient=17;
	E->valeur.nom[9]='Elkhatir';
	E->valeur.prenom[6]='Sanae';
	E->valeur.cin=0334;
	E->valeur.adresse[9]='DAKHLA 72';
	E->valeur.telephone=7153;
	E->suivant=*L1;
	*L1=E;
	listeClient *A=NULL;
	A=(listeClient*)malloc(sizeof(listeClient));
	if(A==NULL){
		printf("Pas d'espace memoire !");
		exit(1);
	}
	A->valeur.idClient=18;
	A->valeur.nom[8]='Elalaoui';
	A->valeur.prenom[9]='Youness';
	A->valeur.cin=0570;
	E->valeur.adresse[12]='TALBORJT 87';
	A->valeur.telephone=4655;
	A->suivant=*L1;
	*L1=A;
	listeClient *Z=*L1;
	FILE *fichier=NULL; /*adds the modified data to the client file*/
	fichier=fopen("client.txt","w");
	if(fichier==NULL){
	printf("Le fichier n'existe pas!");
	}
	else{
		while(Z){
		 fprintf(fichier,"%d %s %s  %d %s %d \n",Z->valeur.idClient,Z->valeur.nom,Z->valeur.prenom,Z->valeur.cin,Z->valeur.adresse,Z->valeur.telephone);
		 Z=Z->suivant;
		}
		fclose(fichier);
	}
}
void AjouterClient(listeClient **L1){
	listeClient *E=NULL;
	E=(listeClient*)malloc(sizeof(listeClient));
	if(E==NULL){
		printf("Pas d'espace memoire !");
		exit(1);
	}
	else{
		printf("Entrer l'id du Client :");
		scanf("%d",&E->valeur.idClient);
		printf("Entrer le nom:");
		scanf("%s",&E->valeur.nom);
		printf("Entrer le prenom:");
		scanf("%s",&E->valeur.prenom);
		printf("Entrer Cin :");
		scanf("%d",&E->valeur.cin);
		printf("Entrer l'adresse:");
		scanf("%s",&E->valeur.adresse);
		printf("Entrer le numero de telephone:");
		scanf("%d",&E->valeur.telephone);
		E->suivant=*L1;
		*L1=E;
		FILE *fichier=NULL; /*adds the modified data to the client file*/
	    fichier=fopen("client.txt","w");
     	if(fichier==NULL){
		printf("Le fichier n'existe pas");
     	}
    	else{
		 while(E){
			fprintf(fichier,"%d %s %s %d %s %d \n",E->valeur.idClient,E->valeur.nom,E->valeur.prenom,E->valeur.cin,E->valeur.adresse,E->valeur.telephone);
		 }
		 fclose(fichier);
	     }
    }
}

void listeclient(){ /*shows the client file data*/
	FILE *fichier=fopen("client.txt","r");
	if(fichier==NULL)
	 printf("Erreur!");
	else{
	 char c;
	 do{
	 	c=fgetc(fichier);
	 	printf("%c",c);
	 }while(c!=EOF);
	}
}
void MOdifierClient(listeClient **L1){
	listeClient *ptr=*L1;
	int ID,i=0;
	printf("Entrer l'id du client :");
	scanf("%d",&ID);
	if(ptr->valeur.idClient==ID){ /*if the client with the entered ID is the first element on the list*/
		printf("Entrer la nouvelle id du Client :");
		scanf("%d",&ptr->valeur.idClient);
		printf("Entrer le nouveau nom:");
		scanf("%s",&ptr->valeur.nom);
		printf("Entrer le nouveau prenom:");
		scanf("%s",&ptr->valeur.prenom);
		printf("Entrer nouveau Cin :");
		scanf("%d",&ptr->valeur.cin);
		printf("Entrer la nouvelle adresse:");
		scanf("%s",&ptr->valeur.adresse);
		printf("Entrer le nouveau numero de telephone:");
		scanf("%d",&ptr->valeur.telephone);
	}
	else{
	while(ptr->suivant!=NULL){
		if(ptr->suivant->valeur.idClient==ID){
		printf("Entrer la nouvelle id de Client :");
		scanf("%d",&ptr->suivant->valeur.idClient);
		printf("Entrer le nouveau Nom:");
		scanf("%s",&ptr->suivant->valeur.nom);
		printf("Entrer le nouveau prenom:");
		scanf("%s",&ptr->suivant->valeur.prenom);
		printf("Entrer nouveau Cin :");
		scanf("%d",&ptr->suivant->valeur.cin);
		printf("Entrer la nouvelle adresse:");
		scanf("%s",&ptr->suivant->valeur.adresse);
		printf("Entrer le nouveau numero de telephone:");
		scanf("%d",&ptr->suivant->valeur.telephone);
		}
		ptr=ptr->suivant;
	}
    }
    listeClient *Z=*L1;
	FILE *fichier=NULL; /*adds the modified data to the client file*/
	fichier=fopen("client.txt","w");
	if(fichier==NULL){
	printf("Le fichier n'existe pas!");
	}
	else{
		while(Z){
		 fprintf(fichier,"%d %s %s  %d %s %d \n",Z->valeur.idClient,Z->valeur.nom,Z->valeur.prenom,Z->valeur.cin,Z->valeur.adresse,Z->valeur.telephone);
		 Z=Z->suivant;
		}
		fclose(fichier);
	}
}

void suppressionClient(listeVoiture **L1){
	listeClient *prec;
	listeClient *ptr=*L1;
	prec=NULL;
	int Id,i=0;
	printf("Entrer l'ID du client:");
	scanf("%d",&Id);
	while(ptr->suivant){ /*finds the car with entered ID and stops at the element preceding it*/
		if(Id==ptr->suivant->valeur.idClient){
		 prec=ptr;
		 i++;
	    }
		ptr=ptr->suivant;
	}
	if(i==0)
	 printf("ID inconnue! \n");
	else{
		ptr=prec->suivant;
		prec->suivant=prec->suivant->suivant;
    }
    listeClient *Z=*L1;
	FILE *fichier=NULL; /*adds the modified data to the client file*/
	fichier=fopen("client.txt","w");
	if(fichier==NULL){
	printf("le fichier nexiste pas");
	}
	else{
		while(Z){
		 fprintf(fichier,"%d %s %s  %d %s %d \n",Z->valeur.idClient,Z->valeur.nom,Z->valeur.prenom,Z->valeur.cin,Z->valeur.adresse,Z->valeur.telephone);
		 Z=Z->suivant;
		}
		fclose(fichier);
	}
}
int main(){
	InitialisationVoiture(&L);
	InitialisationClient(&L1);
	InitialisationContrat(&L2);
	int n=0;
	while(n==0)
	menuprincipal(); /*infinite loop. the execution of the program stops when the client chooses to exit.*/
	return 0;
}
